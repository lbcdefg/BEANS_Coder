package com.springboot.corder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CorderApplicationTests {

	@Test
	void contextLoads() {
	}

}
