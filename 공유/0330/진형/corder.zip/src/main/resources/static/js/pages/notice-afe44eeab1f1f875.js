(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([[1328], {
    32223: function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {
        (window.__NEXT_P = window.__NEXT_P || []).push(["/notice", function() {
            return __webpack_require__(13828)
        }
        ])
    },
    13828: function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__),
        __webpack_require__.d(__webpack_exports__, {
            __N_SSP: function() {
                return __N_SSP
            },
            default: function() {
                return RedirectToInfoPage
            }
        });
        var __N_SSP = !0;
        function RedirectToInfoPage() {
            return null
        }
    }
}, function(__webpack_require__) {
    __webpack_require__.O(0, [9774, 2888, 179], function() {
        return __webpack_require__(__webpack_require__.s = 32223)
    }),
    _N_E = __webpack_require__.O()
}
]);
