(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([[2971], {
    99204: function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {
        (window.__NEXT_P = window.__NEXT_P || []).push(["/questions", function() {
            return __webpack_require__(15369)
        }
        ])
    }
}, function(__webpack_require__) {
    __webpack_require__.O(0, [1664, 8213, 732, 7156, 8485, 9276, 5316, 5172, 9818, 5794, 7357, 5369, 9774, 2888, 179], function() {
        return __webpack_require__(__webpack_require__.s = 99204)
    }),
    _N_E = __webpack_require__.O()
}
]);
