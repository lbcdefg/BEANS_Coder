(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([[662], {
    73406: function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {
        (window.__NEXT_P = window.__NEXT_P || []).push(["/settings", function() {
            return __webpack_require__(89929)
        }
        ])
    },
    89929: function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__),
        __webpack_require__.d(__webpack_exports__, {
            default: function() {
                return _profile__WEBPACK_IMPORTED_MODULE_0__.default
            }
        });
        var _profile__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(63221)
    }
}, function(__webpack_require__) {
    __webpack_require__.O(0, [1664, 8213, 721, 2296, 5175, 7156, 8485, 3221, 9774, 2888, 179], function() {
        return __webpack_require__(__webpack_require__.s = 73406)
    }),
    _N_E = __webpack_require__.O()
}
]);
